use EntityFramework;
create table tblDepartment
(
Id int primary key identity, 
Name nvarchar(50)				
)
Insert into tblDepartment Values('IT')
Insert into tblDepartment Values('HR')
Insert into tblDepartment Values('Payroll')

use EntityFramework;
create table tblEmployee
(
EmployeeId int Primary Key Identity(1,1),
Name nvarchar(50),
Gender nvarchar(10),
City nvarchar(15),
DepartmentId int,
)

Alter table tblEmployee
add foreign key (DepartmentId)
references tblDepartment(Id)

insert into tblEmployee values('Mark', 'Male', 'London', 1)
insert into tblEmployee values('Suraj', 'Male', 'Europe',3)
insert into tblEmployee values('Aron', 'Male', 'London', 2)
insert into tblEmployee values('Augusta', 'Female', 'Australia', 3)
insert into tblEmployee values('Simon', 'Male', 'New York', 3)
insert into tblEmployee values('Juli', 'Female', 'Sydney', 1)

select * from tblDepartment
select * from tblEmployee

use EntityFramework
alter table tblEmployee
add Email nvarchar(20);

select * from tblEmployee;

use EntityFramework;

UPDATE tblEmployee SET Email = 'k.srhdj@gmail.com' where EmployeeId=3; 
UPDATE tblEmployee SET Email = 'm.hdj@gmail.com' where EmployeeId=4; 
UPDATE tblEmployee SET Email = 'hjdj@gmail.com' where EmployeeId=5; 
UPDATE tblEmployee SET Email = 'jdskjcdj@gmail.com' where EmployeeId=6; 
UPDATE tblEmployee SET Email = 'hjj@gmail.com' where EmployeeId=8; 
UPDATE tblEmployee SET Email = 'ggdj@gmail.com' where EmployeeId=9; 

alter table tblEmployee
add Phone int;

UPDATE tblEmployee SET Phone = '12356554' where EmployeeId=3; 
UPDATE tblEmployee SET Phone = '8995552' where EmployeeId=4; 
UPDATE tblEmployee SET Phone = '5522148' where EmployeeId=5;
UPDATE tblEmployee SET Phone = '5522148' where EmployeeId=6; 
UPDATE tblEmployee SET Phone = '5522148' where EmployeeId=8; 
UPDATE tblEmployee SET Phone = '5522148' where EmployeeId=9; 
 
alter table tblEmployee
add Pincode int;

UPDATE tblEmployee SET Pincode = '275101' where EmployeeId=3; 
UPDATE tblEmployee SET Pincode = '256981' where EmployeeId=4; 
UPDATE tblEmployee SET Pincode = '475869' where EmployeeId=5;
UPDATE tblEmployee SET Pincode = '412536' where EmployeeId=6; 
UPDATE tblEmployee SET Pincode = '253669' where EmployeeId=8; 
UPDATE tblEmployee SET Pincode = '586925' where EmployeeId=9; 